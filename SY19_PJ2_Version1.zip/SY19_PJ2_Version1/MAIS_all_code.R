library(lattice)
library(ggplot2)
library(caret)
library(glmnet)
library(Matrix)
library(foreach)
library(FactoMineR)
library(factoextra)
library(leaps)
library(kknn)
library(sampling)
library(class)
library(FNN)
library(e1071)
library(rpart)  
library(rpart.plot)  # tree ploting
library(rsample)     # data splitting 
library(tidyr)
library(dplyr)       # data wrangling
library(ipred)       # bagging
library(caret)       # bagging
library(randomForest)
library(nnet)

# ---------------------Reading data----------------------------
data <- read.csv('mais_train.csv',header = TRUE)
data <- data[, names(data)!='X']
# -------------------------------------------------------------

# ---------------------FAMD------------------------------------
mais <- subset(data, select = -yield_anomaly)

mais[,1] = as.factor(mais$year_harvest)
mais[,2] = as.factor(mais$NUMD)
mais[,3] = as.factor(mais$IRR)

mais[,1] = paste("year",mais[,1])
mais[,2] = paste("NUMD",mais[,2])
mais[,3] = paste("IRR",mais[,3])

# 100: 82.285952%
res.famd <- FAMD(mais, ncp=100,graph = FALSE)

# Eigenvalues / Variances
# The proportion of variances
eig.val <- get_eigenvalue(res.famd)
head(eig.val)
fviz_screeplot(res.famd)
res.famd$eig

# Graph of variables
# All variables
var <- get_famd_var(res.famd)

# Plot of variables
fviz_famd_var(res.famd, repel = TRUE)
#NUMD departement是最有用的？

# Contribution to the first dimension
fviz_contrib(res.famd, "var", axes = 1)

# Contribution to the second dimension
fviz_contrib(res.famd, "var", axes = 2)

# Quantitative variables
quanti.var <- get_famd_var(res.famd, "quanti.var")
fviz_famd_var(res.famd, "quanti.var", col.var = "contrib", 
              gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
              repel = TRUE)

# Qualitative variables
# duplicate 'row.names' are not allowed
#是因为那三列factor都是1234数字表示，画图时无法区分开
quali.var <- get_famd_var(res.famd, "quali.var")
fviz_famd_var(res.famd, "quali.var", col.var = "contrib", 
              gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07")
)

#individuals
ind <- get_famd_ind(res.famd)
# -------------------------------------------------------------

# ----------------------Cook distance--------------------------
mais<-as.data.frame(scale(data))

mod <- lm(yield_anomaly ~ ., data=mais)
cooksd <- cooks.distance(mod)
summary(cooksd)
plot(cooksd, pch="*", cex=2, main="Influential Obs by Cooks distance")  # 绘制Cook距离
# 30 选择最远的三个�?
abline(h = 30*mean(cooksd, na.rm=T), col="red")  # 添加决策�?
text(x=1:length(cooksd)+1, y=cooksd, labels=ifelse(cooksd>30*mean(cooksd, na.rm=T),names(cooksd),""), col="red")  # 添加标签

influential<-names(cooksd[cooksd>=30*mean(cooksd, na.rm=T)])  # 有影响力的观测值行�?
head(mais[influential, ])  # 列出这些观测
mais_outlier<-mais[influential, ]

# delete outliers
data<-data[-as.numeric(influential),]
data.scale<-as.data.frame(scale(data))
# -------------------------------------------------------------

# ---------------------Delete the relatif colonnes-------------
# corr <- cor(data)
# fC <- findCorrelation(corr, cutoff = .8)
# head(data[fC])
# data = data[-fC]
# -------------------------------------------------------------

# -------------------------Dummy variables---------------------
data.dummy<-data
departement <- data.dummy[, names(data.dummy)=='NUMD']
col <- data.frame( ifelse(departement == 1, 1, 0) )
for (i in (2:93)) {
  col <- cbind(col, ifelse(departement == i, 1, 0) )
}
names(col) <- paste("d", 1:93, sep="_")
data.dummy <- data.dummy[, names(data.dummy)!='NUMD']
data.dummy <- cbind(data.dummy, col)

year <- data.dummy[, names(data.dummy)=='year_harvest']
col <- data.frame( ifelse(year >= 1 & year < 10, 1, 0) )
for (i in (2:5)) {
  col <- cbind(col, ifelse(year >= (i-1)*10 & year < i*10, 1,0) )
}
names(col) <- paste("year", 1:5, sep="_")
data.dummy <- data.dummy[, names(data.dummy)!='year_harvest']
data.dummy <- cbind(data.dummy, col)
data.dummy.scale <- as.data.frame(scale(data.dummy))
# -------------------------------------------------------------

# Exploration data
# boxplot(scale(data[,-1]))
# library(FactoMineR)
# pca <- PCA(data[, -1])
# plot(pca$eig[,3], type='l', ylab='cumulative percentage of variance', 
#      xlab="components")
# abline(v=2, col="red", lwd=2)
# abline(h=90, col="red", lwd=2)
# abline(h=95, col="blue", lwd=2)
# abline(h=99, col="yellow", lwd=2)

# -------------------------PCA with Dummy variables---------------------
data.dummy.pca <- data.dummy
pca_princomp <- princomp(data.dummy.pca[,names(data.dummy.pca)!='yield_anomaly'],cor=T)
pca_prcomp <- prcomp(data.dummy.pca[,names(data.dummy.pca)!='yield_anomaly'],scale=T)
lambda<-pca_prcomp$sdev^2
plot(cumsum(lambda)/sum(lambda),type="l",xlab="q",ylab="proportion of explained variance")
abline(h=0.9, col="red", lwd=2)
abline(v=100, col="blue", lwd=2)
q<-100
data.dummy.pca <- as.data.frame(pca_prcomp$x[,1:q])
yield_anomaly <- scale(data$yield_anomaly)
data.dummy.pca <- cbind(data.dummy.pca, yield_anomaly)
data.rotation <- pca_prcomp$rotation
# --------------------------------------------------------------------

# -------------------------------LM-------------dummy, -IRR, scale=>0.6928176------------------
nrow = nrow(data.dummy.scale)
set.seed(1234)
folds<-sample(1:10,nrow,replace=TRUE)
mse.lm<-rep(0,10)
for(k in (1:10)){
  train <- data.dummy.scale[folds!=k,]
  test <- data.dummy.scale[folds==k,names(data.dummy.scale)!='yield_anomaly']
  data.lm <- lm(yield_anomaly~.-IRR, data = train)
  dara.lm.pred <- predict(data.lm, newdata = test)
  mse.lm[k]<-mean((data.dummy.scale$yield_anomaly[folds==k]-dara.lm.pred)^2) 
}
boxplot(mse.lm)
# --------------------------------------------------------------------

# -------------------------------LM pca--------------scale, dummy, pca=>0.8609951-----------------
nrow = nrow(data.dummy.pca)
set.seed(1234)
folds<-sample(1:10,nrow,replace=TRUE)
mse.lm.pca<-rep(0,10)
for(k in (1:10)){
  train <- data.dummy.pca[folds!=k,]
  test <- data.dummy.pca[folds==k,names(data.dummy.pca)!='yield_anomaly']
  data.lm <- lm(yield_anomaly~., data = train)
  dara.lm.pred <- predict(data.lm, newdata = test)
  mse.lm.pca[k]<-mean((data.dummy.pca$yield_anomaly[folds==k]-dara.lm.pred)^2) 
}
boxplot(mse.lm.pca)
# -------------------------------------------------------------------------------

# ------------------------------LM 4 subsets-------------dummy, IRR, scale => 0.4473689-------------------------
set.seed(1234)
reg.forward<-regsubsets(yield_anomaly ~ .,data=data.dummy.scale,method='forward',nvmax=153)
summary.reg.forward<-summary(reg.forward)
#model with max adjr2
reg.forward.adjr2 <- max(summary.reg.forward$adjr2) #max adjr2
choix.reg.forward.adjr2 <- (summary.reg.forward[["which"]][summary.reg.forward$adjr2==reg.forward.adjr2,])
#obtenir les noms de predictors
subset.for.adjr2 <-names(choix.reg.forward.adjr2[choix.reg.forward.adjr2=="TRUE"])
#obtenir le formule de model
formula.reg.forw.adjr2 <- paste0("yield_anomaly~",paste("",subset.for.adjr2[2:length(subset.for.adjr2)],sep="",collapse="+"))
#plot
plot(1:100,summary.reg.forward$adjr2[1:100],xlab = "nombre de variables",ylab = "adjr2")
plot((length(subset.for.adjr2)-10):100,summary.reg.forward$adjr2[(length(subset.for.adjr2)-10):100],xlab = "nombre de variables",ylab = "adjr2",main = "Forward stepwise methode")
abline(h=reg.forward.adjr2)

#model with min bic
reg.forward.bic <- min(summary.reg.forward$bic)  #min bic
choix.reg.forward.bic <- (summary.reg.forward[["which"]][summary.reg.forward$bic==reg.forward.bic,])
subset.for.bic <-names(choix.reg.forward.bic[choix.reg.forward.bic=="TRUE"])
formula.reg.forw.bic <- paste0("yield_anomaly~",paste("",subset.for.bic[2:length(subset.for.bic)],sep="",collapse="+"))
plot((length(subset.for.bic)-10):(length(subset.for.bic)+20),summary.reg.forward$bic[(length(subset.for.bic)-10):(length(subset.for.bic)+20)],xlab = "nombre de variables",ylab = "bic",main = "Forward stepwise methode")
abline(h=reg.forward.bic)
set.seed(1234)
#backward stepwise methode
reg.backward<-regsubsets(yield_anomaly ~.,data=data.dummy.scale,method='backward',nvmax=153)
summary.reg.backward<-summary(reg.backward)
#model with max adjr2
reg.backward.adjr2 <- max(summary.reg.backward$adjr2) #max adjr2
choix.reg.backward.adjr2 <- (summary.reg.backward[["which"]][summary.reg.backward$adjr2==reg.backward.adjr2,])
subset.back.adjr2 <-names(choix.reg.backward.adjr2[choix.reg.backward.adjr2=="TRUE"])
formula.reg.back.adjr2 <- paste0("yield_anomaly~",paste("",subset.back.adjr2[2:length(subset.back.adjr2)],sep="",collapse="+"))
plot((length(subset.back.adjr2)-10):100,summary.reg.backward$adjr2[(length(subset.back.adjr2)-10):100],xlab = "nombre de variables",ylab = "adjr2",main = "Backward stepwise methode")
abline(h=reg.backward.adjr2)
#model with min bic
reg.backward.bic <- min(summary.reg.backward$bic)  #min bic
choix.reg.backward.bic <- (summary.reg.backward[["which"]][summary.reg.backward$bic==reg.backward.bic,])
subset.back.bic <-names(choix.reg.backward.bic[choix.reg.backward.bic=="TRUE"])
formula.reg.back.bic <- paste0("yield_anomaly~",paste("",subset.back.bic[2:length(subset.back.bic)],sep="",collapse="+"))
plot((length(subset.back.bic)-10):(length(subset.back.bic)+20),summary.reg.backward$bic[(length(subset.back.bic)-10):(length(subset.back.bic)+20)],xlab = "nombre de variables",ylab = "bic",main = "Backward stepwise methode")
abline(h=reg.backward.bic)

#cross-validation
#4 subset models
set.seed(1234)
K <- 10
folds = sample(1:K,nrow(data.dummy.scale),replace=TRUE)
mse.lm.subset <- matrix(data=0,nrow = 10,ncol = 6)
Formula <- c(
  formula.reg.forw.adjr2,
  formula.reg.forw.bic,
  formula.reg.back.adjr2,
  formula.reg.back.bic
)
for(i in 1:4){
  for(k in (1:K) ){
    reg.kcross <-lm(Formula[[i]],data = as.data.frame(data.dummy.scale[folds!=k,]))
    pred.kcross <- predict(reg.kcross,newdata = as.data.frame(data.dummy.scale[folds==k,]))
    mse.lm.subset[k,i]<- mean((data.dummy.scale$yield_anomaly[folds==k]-pred.kcross)^2)
  }
}

boxplot(mse.lm.subset[,c(1:4)],names=c("forw.adjr2","forw.bic","back.adjr2","back.bic"),xlab="Models", ylab="MSE") #MSE_L
mean(mse.lm.subset)
# --------------------------------------------------------------------------------

# ------------------------------LM 4 subsets pca-------------dummy, IRR, scale, pca=>0.5441271---------------------
set.seed(1234)
reg.forward<-regsubsets(yield_anomaly ~ .,data=data.dummy.pca,method='forward',nvmax=153)
summary.reg.forward<-summary(reg.forward)
#model with max adjr2
reg.forward.adjr2 <- max(summary.reg.forward$adjr2) #max adjr2
choix.reg.forward.adjr2 <- (summary.reg.forward[["which"]][summary.reg.forward$adjr2==reg.forward.adjr2,])
#obtenir les noms de predictors
subset.for.adjr2 <-names(choix.reg.forward.adjr2[choix.reg.forward.adjr2=="TRUE"])
#obtenir le formule de model
formula.reg.forw.adjr2 <- paste0("yield_anomaly~",paste("",subset.for.adjr2[2:length(subset.for.adjr2)],sep="",collapse="+"))

#model with min bic
reg.forward.bic <- min(summary.reg.forward$bic)  #min bic
choix.reg.forward.bic <- (summary.reg.forward[["which"]][summary.reg.forward$bic==reg.forward.bic,])
subset.for.bic <-names(choix.reg.forward.bic[choix.reg.forward.bic=="TRUE"])
formula.reg.forw.bic <- paste0("yield_anomaly~",paste("",subset.for.bic[2:length(subset.for.bic)],sep="",collapse="+"))

set.seed(1234)
#backward stepwise methode
reg.backward<-regsubsets(yield_anomaly ~.,data=data.dummy.pca,method='backward',nvmax=153)
summary.reg.backward<-summary(reg.backward)
#model with max adjr2
reg.backward.adjr2 <- max(summary.reg.backward$adjr2) #max adjr2
choix.reg.backward.adjr2 <- (summary.reg.backward[["which"]][summary.reg.backward$adjr2==reg.backward.adjr2,])
subset.back.adjr2 <-names(choix.reg.backward.adjr2[choix.reg.backward.adjr2=="TRUE"])
formula.reg.back.adjr2 <- paste0("yield_anomaly~",paste("",subset.back.adjr2[2:length(subset.back.adjr2)],sep="",collapse="+"))

#model with min bic
reg.backward.bic <- min(summary.reg.backward$bic)  #min bic
choix.reg.backward.bic <- (summary.reg.backward[["which"]][summary.reg.backward$bic==reg.backward.bic,])
subset.back.bic <-names(choix.reg.backward.bic[choix.reg.backward.bic=="TRUE"])
formula.reg.back.bic <- paste0("yield_anomaly~",paste("",subset.back.bic[2:length(subset.back.bic)],sep="",collapse="+"))


#cross-validation
#4 subset models
set.seed(1234)
K <- 10
folds = sample(1:K,nrow(data.dummy.pca),replace=TRUE)
mse.lm.subset.pca <- matrix(data=0,nrow = 10,ncol = 6)
Formula <- c(
  formula.reg.forw.adjr2,
  formula.reg.forw.bic,
  formula.reg.back.adjr2,
  formula.reg.back.bic
)
for(i in 1:4){
  for(k in (1:K) ){
    reg.kcross <-lm(Formula[[i]],data = as.data.frame(data.dummy.pca[folds!=k,]))
    pred.kcross <- predict(reg.kcross,newdata = as.data.frame(data.dummy.pca[folds==k,]))
    mse.lm.subset.pca[k,i]<- mean((data.dummy.pca$yield_anomaly[folds==k]-pred.kcross)^2)
  }
}

boxplot(mse.lm.subset.pca[,c(1:4)],names=c("forw.adjr2","forw.bic","back.adjr2","back.bic"),xlab="Models", ylab="MSE") #MSE_L
mean(mse.lm.subset.pca)
# --------------------------------------------------------------------------------

# ------------------------Regularization-----------------scale, IRR, dummy => 0.6839802, alpha=0.5-----------------
# Entrée : alpha spécific, learning dataset, test dataset
regularization.pred<- function(alpha, train, test) {
  xapp <- as.matrix(train[,names(train)!='yield_anomaly'])
  yapp <- train$yield_anomaly
  xtst <- as.matrix(test[,names(test)!='yield_anomaly'])
  ytst <- test$yield_anomaly
  cv.out <- cv.glmnet(xapp,yapp,alpha = alpha)
  fit <- glmnet(xapp, yapp, lambda = cv.out$lambda.min, alpha = alpha)
  pred <- predict(fit, s=cv.out$lamda.min, newx = xtst)
  return (sum((ytst-pred)^2))
}
# alpha = 1: lasso, alpha = 0: ridge
alpha <- seq(0, 1, by = .1)
set.seed(1234)
folds <- sample(1:10, nrow, replace=TRUE)
CV <- rep(0,11)
for(i in (1:11)) {
  for(k in (1:10)) {
    error <- regularization.pred(alpha[i], data.dummy.scale[folds!=k,], data.dummy.scale[folds==k,])
    CV[i] <- CV[i] + error
  }
  CV[i] <- CV[i]/nrow
}
mse.regularization<-min(CV)
alpha <- alpha[which.min(CV)]
alpha

folds<-sample(1:10,nrow,replace=TRUE)
mse.regularization<-rep(0,10)
for(k in (1:10)){
  error <- regularization.pred(alpha, data.dummy.scale[folds!=k,], data.dummy.scale[folds==k,])
  mse.regularization[k]<-error/nrow(data.dummy.scale[folds==k,])
}
boxplot(mse.regularization)
mean(mse.regularization)
# -----------------------------------------------------------------------------------------------------

# ------------------------Regularization pca-----------------scale, IRR, dummy,pca => 0.8287755--------------------
# alpha = 1: lasso, alpha = 0: ridge
alpha <- seq(0, 1, by = .1)
set.seed(1234)
folds <- sample(1:10, nrow, replace=TRUE)
CV <- rep(0,11)
for(i in (1:11)) {
  for(k in (1:10)) {
    error <- regularization.pred(alpha[i], data.dummy.pca[folds!=k,], data.dummy.pca[folds==k,])
    CV[i] <- CV[i] + error
  }
  CV[i] <- CV[i]/nrow
}
mse.regularization<-min(CV)
alpha <- alpha[which.min(CV)]
alpha

folds<-sample(1:10,nrow,replace=TRUE)
mse.regularization<-rep(0,10)
for(k in (1:10)){
  error <- regularization.pred(alpha, data.dummy.pca[folds!=k,], data.dummy.pca[folds==k,])
  mse.regularization[k]<-error/nrow(data.dummy.pca[folds==k,])
}
boxplot(mse.regularization)
mean(mse.regularization)
# -----------------------------------------------------------------------------------------------------

# --------------------------------------KNN----------dummy,scale,IRR=>0.8675853--------------------------------
nb.reg <- nrow(data.dummy.scale)
nb.train <- round(2*nb.reg/3)
nb.validation <- nb.reg-nb.train
set.seed(1234)
train <- sample(1:nb.reg,nb.train)
mais.train <- as.data.frame(data.dummy.scale[train,])
mais.validation <- as.data.frame(data.dummy.scale[-train,])

rmse = function(actual, predicted) {
  sqrt(mean((actual - predicted) ^ 2))
}

make_knn_pred = function(k = 1, training, predicting) {
  pred = FNN::knn.reg(train = training, 
                      test = predicting, 
                      y = training$yield_anomaly, k = k)$pred
  act  = predicting$yield_anomaly
  rmse(predicted = pred, actual = act)
}

# define values of k to evaluate
k = c(1, 5, 10, 25, 50, 250, 500, 750, 1000, 1250, 1500)


# get requested train RMSEs
knn_trn_rmse = sapply(k, make_knn_pred, 
                      training = mais.train, 
                      predicting = mais.train)
# get requested test RMSEs
knn_tst_rmse = sapply(k, make_knn_pred, 
                      training = mais.train, 
                      predicting = mais.validation)

# determine "best" k
best_k = k[which.min(knn_tst_rmse)]

# find overfitting, underfitting, and "best"" k
fit_status = ifelse(k < best_k, "Over", ifelse(k == best_k, "Best", "Under"))

# summarize results
knn_results = data.frame(
  k,
  round(knn_trn_rmse, 2),
  round(knn_tst_rmse, 2),
  fit_status
)
colnames(knn_results) = c("k", "Train RMSE", "Test RMSE", "Fit?")

# display results
knitr::kable(knn_results, escape = FALSE, booktabs = TRUE)

#cross-validation avec knn k=50
set.seed(1234)
K <- 10
folds = sample(1:K,(nb.train+nb.validation),replace=TRUE)
mse.knn <- matrix(data=0,nrow = 10,ncol = 1)
for(k in (1:K) ){
  mse.knn[k] <- sapply(50, make_knn_pred, 
                  training = data.dummy.scale[folds!=k,], 
                  predicting = data.dummy.scale[folds==k,])
}
boxplot(mse.knn)
# -----------------------------------------------------------------------------------------------------

# ------------------------------------SVR----------------scale=>0.5257915------------------------------
set.seed(1234)
K <- 10
folds = sample(1:K,nrow,replace=TRUE)
mse.svr <- matrix(data=0,nrow = 10,ncol = 1)
for(k in (1:K) ){
  reg.kcross <- svm(yield_anomaly ~ . , data.scale[folds!=k,])
  pred.kcross <- predict(reg.kcross,newdata = as.data.frame(data.scale[folds==k,]))
  mse.svr[k]<- mean((data.scale$yield_anomaly[folds==k]-pred.kcross)^2)
}
boxplot(mse.svr)
# -----------------------------------------------------------------------------------------------------

# ------------------------------------SVR-----------no scale=>0.5257915------------------------------
set.seed(1234)
K <- 10
folds = sample(1:K,nrow,replace=TRUE)
mse.svr.noscale <- matrix(data=0,nrow = 10,ncol = 1)
for(k in (1:K) ){
  reg.kcross <- svm(yield_anomaly ~ . , data[folds!=k,])
  pred.kcross <- predict(reg.kcross,newdata = as.data.frame(data[folds==k,]))
  mse.svr.noscale[k]<- mean((data$yield_anomaly[folds==k]-pred.kcross)^2)
}
boxplot(mse.svr.noscale)
# -----------------------------------------------------------------------------------------------------


# ------------------------------------Tree---------=>0.7718452---------------------------
set.seed(1234)
folds<-sample(1:10,nrow,replace=TRUE)
mse.tree<-rep(0,10)
for(k in (1:10)){
  idx.train <- which(folds!=k)
  fit.tree <-rpart(yield_anomaly ~ ., data=data, subset = idx.train, method="anova")
  pred.tree <- predict(fit.tree, newdata=data[-idx.train,]) 
  mse.tree[k]<-mean((data[-idx.train, "yield_anomaly"]-pred.tree)^2) 
}
boxplot(mse.tree)
k <- which.min(mse.tree)
idx.train <- which(folds!=k)
fit.tree <-rpart(yield_anomaly ~ ., data=data, subset = idx.train, method="anova")
# plot(fit.tree)
# text(fit.tree, minlength=0.5, cex=0.5, splits=TRUE)
rpart.plot(fit.tree, box.palette="RdBu", shadow.col="gray", fallen.leaves=FALSE)
# ------------------------------------------------------------------------------------------

# -------------------------------bagging tree----------------------=>0.6383903-------------------------------------
set.seed(1234)
mais_split <- initial_split(data, prop = .7)
mais_train <- training(mais_split)
mais_test  <- testing(mais_split)

# assess 10-1500 bagged tree size
ntree <- c(10,100,200,500,1000,1500)

# create empty vector to store OOB RMSE values
rmse <- vector(mode = "numeric", length = length(ntree))

for (i in seq_along(ntree)) {
  set.seed(1234)
  # perform bagged model
  model <- bagging(formula = yield_anomaly ~ ., data = mais_train, coob = TRUE, nbagg   = ntree[i])
  # get OOB error
  rmse[i] <- model$err
}

plot(ntree, rmse, type = 'l', lwd = 2)
abline(v =200, col = "red", lty = "dashed")
#图说明应该bagging更多的树
min(rmse) 

set.seed(1234)
K <- 10
folds = sample(1:K,nrow,replace=TRUE)
mse.bag <- matrix(data=0,nrow = 10,ncol = 1)

for(k in (1:K) ){
  model <- bagging(formula = yield_anomaly ~ ., data = as.data.frame(data[folds!=k,]), coob = TRUE, nbagg   = 200)
  pred.kcross <- predict(model,newdata = as.data.frame(data[folds==k,]))
  mse.bag[k]<- mean((data$yield_anomaly[folds==k]-pred.kcross)^2)
}
boxplot(mse.bag)
mean(mse.bag)
# ------------------------------------------------------------------------------------------

# ----------------------------------RandomForest--------0.5291613--------------------------
set.seed(1234)
folds<-sample(1:10,nrow,replace=TRUE)
mse.RF<-rep(0,10)
for(k in (1:10)){
  idx.train <- which(folds!=k)
  fit.RF <- randomForest(yield_anomaly ~ .,data=data,subset=idx.train) 
  pred.RF <-predict(fit.RF,newdata=data[-idx.train,],type="response") 
  mse.RF[k] <- mean((data[-idx.train, "yield_anomaly"]-pred.RF)^2) 
}
boxplot(mse.RF)
# ------------------------------------------------------------------------------------------

# ----------------------------------RandomForest--------dummy, subset 0.5507432--------------------------
set.seed(1234)
folds<-sample(1:10,nrow,replace=TRUE)
mse.RF.subset<-rep(0,10)
for(k in (1:10)){
  idx.train <- which(folds!=k)
  fit.RF <- randomForest(yield_anomaly~IRR+ETP_2+ETP_3+ETP_4+ETP_5+ETP_6+ETP_7+ETP_8+ETP_9+PR_1+PR_2+PR_3+PR_4+PR_5+PR_6+PR_7+PR_8+RV_1+RV_3+RV_5+RV_6+RV_7+RV_8+RV_9+SeqPR_2+SeqPR_5+SeqPR_7+SeqPR_9+Tn_1+Tn_3+Tn_4+Tn_6+Tn_7+Tn_8+Tn_9+Tx_4+Tx_5+Tx_6+Tx_7+Tx_8+Tx_9+d_1+d_3+d_4+d_5+d_6+d_8+d_12+d_17+d_18+d_19+d_25+d_26+d_27+d_30+d_31+d_32+d_33+d_34+d_35+d_37+d_38+d_41+d_43+d_44+d_45+d_47+d_50+d_51+d_52+d_56+d_58+d_60+d_61+d_63+d_68+d_69+d_71+d_72+d_73+d_74+d_75+d_76+d_78+d_79+d_80+d_81+d_82+d_83+d_85+d_87+d_88+d_89+d_90+d_92+year_1+year_4,data=data.dummy,subset=idx.train) 
  pred.RF <-predict(fit.RF,newdata=data.dummy[-idx.train,],type="response") 
  mse.RF.subset[k] <- mean((data.dummy[-idx.train, "yield_anomaly"]-pred.RF)^2) 
}
boxplot(mse.RF.subset)
mean(mse.RF.subset)
# ------------------------------------------------------------------------------------------

# -----------------------------------neural network------------scale=>0.8180768------------------------------------
K <- 10
folds = sample(1:K,nrow,replace=TRUE)
mse.nnet <- matrix(data=0, nrow = 10,ncol = 1)

for(k in (1:K) ){
  reg.kcross <- nnet(yield_anomaly ~ . , data.scale[folds!=k,],size=15,decay=0.5,trace=FALSE)
  pred.kcross <- predict(reg.kcross,newdata = as.data.frame(data.scale[folds==k,]))
  mse.nnet[k]<- mean((data.scale$yield_anomaly[folds==k]-pred.kcross)^2)
}
boxplot(mse.nnet)
mean(mse.nnet)
# ---------------------------------------------------------------------------------------------------------

boxplot(mse.lm,mse.lm.pca,mse.lm.subset[,1],mse.lm.subset[,2],mse.lm.subset[,3],mse.lm.subset[,4],mse.regularization,mse.knn,mse.svr,mse.svr.noscale,mse.tree,mse.bag,mse.RF,mse.RF.subset,mse.nnet,
        names=c("lm","lm.pca","forw.adjr2","forw.bic","back.adjr2","back.bic","reg","knn","svr","svr nonscale","tree","bagging","RF","RF.subset","neural"),xlab="Models", ylab="MSE") #MSE_L

# 
# summarize results
names=c("lm","lm.pca","forw.adjr2","forw.bic","back.adjr2","back.bic","reg","knn","svr","svr nonscale","tree","bagging","RF","RF.subset","neural")
mses=cbind(mse.lm,mse.lm.pca,mse.lm.subset[,1],mse.lm.subset[,2],mse.lm.subset[,3],mse.lm.subset[,4],mse.regularization,mse.knn,mse.svr,mse.svr.noscale,mse.tree,mse.bag,mse.RF,mse.RF.subset,mse.nnet)
mean_method<-apply(mses, 2, mean)
results = data.frame(
  names,mean_method
)
colnames(results) = c("method", "MSE")

# display results
knitr::kable(results, escape = FALSE, booktabs = TRUE)

library(flexmix)
k<-5
res<-flexmix(yield_anomaly~.,data = as.list(data),k=K,model=FLXMRglm(family="gaussian"), concomitant=FLXPmultinom(formula=~.))
beta<- parameters(res)[1:2,] 
alpha<-res@concomitant@coef

xt<-seq(0,60,0.1)
Nt<-length(xt)
pit<-matrix(0,Nt,K)
for(k in 1:K){
  pit[,k]<-exp(alpha[1,k]+alpha[2,k]*xt) 
}
pit<-pit/rowSums(pit)
plot(xt,pit[,1],type="l",col=1)
for(k in 2:K) lines(xt,pit[,k],col=k)

yhat<-rep(0,Nt)
for(k in 1:K) yhat<-yhat+pit[,k]*(beta[1,k]+beta[2,k]*xt)

#