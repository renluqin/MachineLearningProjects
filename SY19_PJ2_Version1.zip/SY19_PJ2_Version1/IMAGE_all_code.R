library(OpenImageR) # HOG_apply
library(imager) # load.image, resize
library(kernlab)

# get images data
resize.images<-function(path){
  pages <- list.files(path = path,full.names = TRUE)
  for(x in 1:length(pages)) {
    file <- load.image(pages[x])
    resized <- resize(file, 200, 200)
    save.image(resized, file = gsub("JPG", "jpg", paste(pages[x])))
  }
}
path <- file.path(getwd(), 'car','/')
car<-HOG_apply(path, cells = 3, orientations = 6, threads = 1)$hog
car<-as.data.frame(car)
class<-rep("car", nrow(car))
car<-cbind(car,class)

path <- file.path(getwd(), 'cat','/')
resize.images(path)
cat<-HOG_apply(path, cells = 3, orientations = 6, threads = 1)$hog
cat<-as.data.frame(cat)
class<-rep("cat", nrow(cat))
cat<-cbind(cat,class)

path <- file.path(getwd(), 'flower','/')
resize.images(path)
flower<-HOG_apply(path, cells = 3, orientations = 6, threads = 1)$hog
flower<-as.data.frame(flower)
class<-rep("flower", nrow(flower))
flower<-cbind(flower,class)

data <- rbind(car, cat, flower)

# Remove pixels with constant value
# s<-apply(data[,names(data)!='class'],2,sd)
# ii<-which(s>1)
# data<-data[,ii]

# PCA
set.seed(1234)
x<-scale(data[,names(data)!='class'])
pca<-prcomp(x)
lambda<-pca$sdev^2

pairs(pca$x[,1:5],col=data[,'class'],pch=as.numeric(data[,'class']))
plot(cumsum(lambda)/sum(lambda),type="l",xlab="q",ylab="proportion of explained variance")
abline(h=0.9,col="blue",lwd=2)
abline(v=25,col="red",lwd=2)
q<-25
x.pca<-scale(pca$x[,1:q])
y<-as.factor(data[,'class'])
n<-nrow(x.pca)
set.seed(1234)
CC<-c(0.001,0.01,0.1,1,10,100,1000,10e4)
N<-length(CC)
M<-10 # nombre de r��p��titions de la validation crois��e
err<-matrix(0,N,M)
set.seed(1234)
for(k in 1:M){
  for(i in 1:N){
    err[i,k]<-cross(ksvm(x=x.pca,y=y,kernel="rbfdot",C=CC[i],cross=5))
  }
}
set.seed(1234)
Err<-rowMeans(err)
plot(CC,Err,type="b",log="x",xlab="C",ylab="CV error")
C<-CC[which.min(Err)]#C=10
err<-cross(ksvm(x=x.pca,y=y,kernel="rbfdot",C=C,cross=10))

#devtools::install_github("rstudio/keras")
#install.packages("keras")
library(keras)
#install_keras()
mnist <- dataset_mnist()
x_train <- mnist$train$x
y_train <- mnist$train$y
x_test <- mnist$test$x
y_test <- mnist$test$y


car<-rep(0,485)
cat<-rep(1,590)
flower<-rep(2,521)
y<-c(car,cat,flower)


#install.packages("magick")
library(magick)
path <- file.path(getwd(), 'car','/')
pages <- list.files(path = path,full.names = TRUE)
car<-rep(0,length(pages))
img <- image_read(pages[1])
rgb <- image_convert(img, colorspace='gray')
rgb <- image_resize(rgb, 28)
rgb <- as.integer(image_data(rgb))[, , 1]
rgb.matrix <- array_reshape(rgb, c(1, 784))
for(x in 2:length(pages)) {
  img <- image_read(pages[x])
  rgb <- image_convert(img, colorspace='gray')
  rgb <- image_resize(rgb, 28)
  rgb <- as.integer(image_data(rgb))[, , 1]
  rgb.matrix <- rbind(rgb.matrix,array_reshape(rgb, c(1, 784)))
}

path <- file.path(getwd(), 'cat','/')
pages <- list.files(path = path,full.names = TRUE)
cat<-rep(1,length(pages))
for(x in 1:length(pages)) {
  img <- image_read(pages[x])
  rgb <- image_convert(img, colorspace='gray')
  rgb <- image_resize(rgb, 28)
  rgb <- as.integer(image_data(rgb))[, , 1]
  rgb.matrix <- rbind(rgb.matrix,array_reshape(rgb, c(1, 784)))
}

path <- file.path(getwd(), 'flower','/')
pages <- list.files(path = path,full.names = TRUE)
flower<-rep(2,length(pages))
for(x in 1:length(pages)) {
  img <- image_read(pages[x])
  rgb <- image_convert(img, colorspace='gray')
  rgb <- image_resize(rgb, 28)
  rgb <- as.integer(image_data(rgb))[, , 1]
  rgb.matrix <- rbind(rgb.matrix,array_reshape(rgb, c(1, 784)))
}

y<-c(car,cat,flower)
y<-data.frame(y)
head(y)
data<-cbind(rgb.matrix,y)


nb.reg <- nrow(data)
nb.train <- round(2*nb.reg/3)
nb.validation <- nb.reg-nb.train
set.seed(1234)
train <- sample(1:nb.reg,nb.train)
data.train <- data[train,]
data.validation <- data[-train,]


mnist <- dataset_mnist()
x_train <- mnist$train$x
y_train <- mnist$train$y
x_test <- mnist$test$x
y_test <- mnist$test$y


# reshape
x_train <- array_reshape(x_train, c(nrow(x_train), 784))
x_test <- array_reshape(x_test, c(nrow(x_test), 784))
# rescale
x_train <- x_train / 255
x_test <- x_test / 255

# rescale
x_train <- data.train[,1:784] / 255
x_test <- data.validation[,1:784] / 255
rownames(x_train)<-1:nrow(x_train)
y_train <- data.train[,785]
y_test <- data.validation[,785]

y_train <- to_categorical(data.train[,785], 3)
y_test <- to_categorical(data.validation[,785], 3)


model <- keras_model_sequential()
model %>% 
  layer_dense(units = 256, activation = 'relu', input_shape = c(784)) %>% 
  layer_dropout(rate = 0.4) %>% 
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dropout(rate = 0.3) %>%
  layer_dense(units = 3, activation = 'softmax')

model %>% compile(
  loss = 'categorical_crossentropy',
  optimizer = optimizer_rmsprop(),
  metrics = c('accuracy')
)
history <- model %>% fit(
  as.matrix(x_train), as.matrix(y_train), 
  epochs = 60, batch_size = 128, 
  validation_split = 0.2
)
plot(history)
model %>% evaluate(as.matrix(x_test), as.matrix(y_test))

