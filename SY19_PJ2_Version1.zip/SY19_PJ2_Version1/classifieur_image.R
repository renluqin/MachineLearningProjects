classifieur_images <- function(list) {
  new_model <- load_model_tf("model")
  n<-length(list)
  file <- load.image(list[1])
  resizedMatrix <- resize(file, 32, 32)
  for(i in 2:n){
    file <- load.image(list[i])
    resizedMatrix <- rbind(resizedMatrix,resize(file, 32, 32))
  }
  dim(resizedMatrix)<-c(n,32,32,3)
  predictions<-new_model %>% predict_classes(resizedMatrix)
  predictions[predictions==0]<-'car'
  predictions[predictions==1]<-'cat'
  predictions[predictions==2]<-'flower'
  return(predictions)
}
#test
path <- file.path('E:/France/SY19/TP/SY19_Projet2/Donnees du TP 10-20191216_test/images_train/images_train/test','/')
list <- list.files(path = path,full.names = TRUE)
classifieur_images(list)
#60 miss 2