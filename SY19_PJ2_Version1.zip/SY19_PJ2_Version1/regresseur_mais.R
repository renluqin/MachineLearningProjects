regresseur_mais <- function(dataset) {
  load("env.Rdata")
  predictions <- predict(mais.svr.model,newdata = dataset)
  return(predictions)
}
#test
data <- read.csv(file = "mais_train.csv", header = TRUE,na.strings="?",row.names=NULL)
mais <- subset(data, select = -X )
mais <- subset(mais, select = -yield_anomaly )
preds <- regresseur_mais(mais)
#error
mse.test <- mean((data$yield_anomaly-preds)^2)#0.3495977
