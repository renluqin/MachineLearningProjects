1. env.Rdata : mais dataset -- SVR model (best model)
2. image_cnn_model : image dataset -- CNN model (best model)
3. classifieur_image.R & regresseur_mais.R : serve for testing with new dataset
4. MAIS_all_code & IMAGE_all_code : includes all models for MAIS and IMAGE